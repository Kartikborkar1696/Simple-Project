Please see the assignment page here: [http://bcustech.github.io/devops-test](http://bcustech.github.io/devops-test)

You can fork this repo but please do not create pull requests against it.