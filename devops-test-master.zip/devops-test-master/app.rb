require 'sinatra'

get '/' do
  'Hello world!'
end
